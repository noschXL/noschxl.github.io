/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.util.Arrays;

abstract class h {
    final short[] H = new short[2];
    final short[][] I = new short[16][8];
    final short[][] J = new short[16][8];
    final short[] K = new short[256];

    h() {
    }

    final void c() {
        int n;
        Arrays.fill(this.H, (short)1024);
        for (n = 0; n < this.I.length; ++n) {
            Arrays.fill(this.I[n], (short)1024);
        }
        for (n = 0; n < this.I.length; ++n) {
            Arrays.fill(this.J[n], (short)1024);
        }
        Arrays.fill(this.K, (short)1024);
    }
}
