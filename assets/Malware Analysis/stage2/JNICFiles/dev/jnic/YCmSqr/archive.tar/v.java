/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.util.Arrays;

abstract class v {
    final short[] N = new short[768];

    v() {
    }

    final void c() {
        Arrays.fill(this.N, (short)1024);
    }
}
