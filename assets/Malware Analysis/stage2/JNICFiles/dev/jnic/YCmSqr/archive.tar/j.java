/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

abstract class j {
    final int L;
    final int M;

    j(int n, int n2) {
        this.L = n;
        this.M = (1 << n2) - 1;
    }
}
