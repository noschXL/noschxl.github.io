/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.io.IOException;

import dev.jnic.YCmSqr.G;
import dev.jnic.YCmSqr.h;

final class V
extends h {
    private /* synthetic */ G T;

    private V(G g) throws IOException{
        this.T = g;
    }

    final int c(int n2)  throws IOException{
        if (this.T.O.a(this.H, 0) == 0) {
            return this.T.O.a(this.I[n2]) + 2;
        }
        if (this.T.O.a(this.H, 1) == 0) {
            return this.T.O.a(this.J[n2]) + 2 + 8;
        }
        return this.T.O.a(this.K) + 2 + 8 + 8;
    }

    /* synthetic */ V(G g, byte by) throws IOException{
        this(g);
    }
}
