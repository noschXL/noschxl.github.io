/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import dev.jnic.YCmSqr.a;
import dev.jnic.YCmSqr.v;

final class S
extends v {
    final /* synthetic */ a V;

    private S(a a2) {
        this.V = a2;
    }

    /* synthetic */ S(a a2, byte by) {
        this(a2);
    }
}
