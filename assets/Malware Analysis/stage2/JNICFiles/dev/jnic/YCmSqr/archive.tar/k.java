/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

final class k {
    int S;

    k() {
    }
}
