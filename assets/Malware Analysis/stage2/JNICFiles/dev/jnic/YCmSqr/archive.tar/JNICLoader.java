/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import dev.jnic.YCmSqr.G;
import dev.jnic.YCmSqr.n;
import dev.jnic.YCmSqr.x;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class JNICLoader
extends InputStream {
    public static ByteBuffer z;
    private String V = "3.7.0";
    private DataInputStream b;
    private n c;
    private x d;
    private G e;
    private int f = 0;
    private boolean g = false;
    private boolean h = true;
    private boolean i = true;
    private boolean j = false;
    private IOException k = null;
    private final byte[] l = new byte[1];

    public JNICLoader(InputStream inputStream) {
        this(inputStream, 0x800000, null);
    }

    public JNICLoader(InputStream inputStream, int n, byte[] byArray) {
        this(inputStream, n, byArray,(byte) 0);
    }

    private JNICLoader(InputStream inputStream, int StartIndex, byte[] byArray, byte by) {
        if (inputStream == null) {
            throw new NullPointerException();
        }
        this.b = new DataInputStream(inputStream);
        this.d = new x();
        int EndIndex = StartIndex;
        if (EndIndex < 4096 || EndIndex > 0x7FFFFFF0) {
            throw new IllegalArgumentException();
        }
        this.c = new n(EndIndex + 15 & 0xFFFFFFF0, byArray);
        if (byArray != null && byArray.length > 0) {
            this.h = false;
        }
    }

    @Override
    public int read() throws IOException {
        JNICLoader jNICLoader = this;
        if (jNICLoader.read(jNICLoader.l, 0, 1) == -1) {
            return -1;
        }
        return this.l[0] & 0xFF;
    }

    @Override
    public int read(byte[] byArray, int StartIndex, int EndIndex) throws IOException{
        if (StartIndex < 0 || EndIndex < 0 || StartIndex + EndIndex < 0 || StartIndex + EndIndex > byArray.length) {
            throw new IndexOutOfBoundsException();
        }
        if (EndIndex == 0) {
            return 0;
        }
        if (this.b == null) {
            throw new IOException();
        }
        if (this.k != null) {
            throw this.k;
        }
        if (this.j) {
            return -1;
        }
        try {
            int n4 = 0;
            while (EndIndex > 0) {
                n n5;
                int n6;
                int n7;
                if (this.f == 0) {
                    JNICLoader jNICLoader = this;
                    n7 = jNICLoader.b.readUnsignedByte();
                    if (n7 == 0) {
                        jNICLoader.j = true;
                        jNICLoader.b();
                    } else {
                        Object object;
                        if (n7 >= 224 || n7 == 1) {
                            jNICLoader.i = true;
                            jNICLoader.h = false;
                            object = jNICLoader.c;
                            jNICLoader.c.o = 0;
                            ((n)object).p = 0;
                            ((n)object).q = 0;
                            ((n)object).r = 0;
                            ((n)object).m[((n)object).n - 1] = 0;
                        } else if (jNICLoader.h) {
                            throw new IOException();
                        }
                        if (n7 >= 128) {
                            int n8;
                            jNICLoader.g = true;
                            jNICLoader.f = (n7 & 0x1F) << 16;
                            jNICLoader.f += jNICLoader.b.readUnsignedShort() + 1;
                            n6 = jNICLoader.b.readUnsignedShort() + 1;
                            if (n7 >= 192) {
                                int n9;
                                jNICLoader.i = false;
                                object = jNICLoader;
                                n7 = ((JNICLoader)object).b.readUnsignedByte();
                                if (n7 > 224) {
                                    throw new IOException();
                                }
                                n8 = n7 / 45;
                                n7 -= n8 * 9 * 5;
                                if ((n7 -= (n9 = n7 / 9) * 9) + n9 > 4) {
                                    throw new IOException();
                                }
                                ((JNICLoader)object).e = new G(((JNICLoader)object).c, ((JNICLoader)object).d, n7, n9, n8);
                            } else {
                                if (jNICLoader.i) {
                                    throw new IOException();
                                }
                                if (n7 >= 160) {
                                    jNICLoader.e.c();
                                }
                            }
                            n8 = n6;
                            DataInputStream dataInputStream = jNICLoader.b;
                            object = jNICLoader.d;
                            if (n8 < 5) {
                                throw new IOException();
                            }
                            if (dataInputStream.readUnsignedByte() != 0) {
                                throw new IOException();
                            }
                            ((x)object).X = dataInputStream.readInt();
                            ((x)object).W = -1;
                            ((x)object).p = ((x)object).m.length - (n8 -= 5);
                            dataInputStream.readFully(((x)object).m, ((x)object).p, n8);
                        } else {
                            if (n7 > 2) {
                                throw new IOException();
                            }
                            jNICLoader.g = false;
                            jNICLoader.f = jNICLoader.b.readUnsignedShort() + 1;
                        }
                    }
                    if (this.j) {
                        if (n4 == 0) {
                            return -1;
                        }
                        return n4;
                    }
                }
                int n10 = Math.min(this.f, EndIndex);
                if (!this.g) {
                    n6 = n10;
                    DataInputStream dataInputStream = this.b;
                    n5 = this.c;
                    int n11 = Math.min(n5.n - n5.p, n6);
                    dataInputStream.readFully(n5.m, n5.p, n11);
                    n5.p += n11;
                    if (n5.q < n5.p) {
                        n5.q = n5.p;
                    }
                } else {
                    n7 = n10;
                    n5 = this.c;
                    n5.r = n5.n - n5.p <= n7 ? n5.n : n5.p + n7;
                    this.e.d();
                }
                n6 = StartIndex;
                byte[] byArray2 = byArray;
                n5 = this.c;
                int n12 = n5.p - n5.o;
                if (n5.p == n5.n) {
                    n5.p = 0;
                }
                System.arraycopy(n5.m, n5.o, byArray2, n6, n12);
                n5.o = n5.p;
                int n13 = n12;
                StartIndex += n13;
                EndIndex -= n13;
                n4 += n13;
                this.f -= n13;
                if (this.f != 0) continue;
                x x2 = this.d;
                if (x2.p == x2.m.length && x2.X == 0 && !(this.c.s > 0)) continue;
                throw new IOException();
            }
            return n4;
        }
        catch (IOException iOException) {
            this.k = iOException;
            throw iOException;
        }
    }

    @Override
    public int available() throws IOException{
        if (this.b == null) {
            throw new IOException("closed");
        }
        if (this.k != null) {
            throw this.k;
        }
        if (this.g) {
            return this.f;
        }
        return Math.min(this.f, this.b.available());
    }

    private void b() {
        if (this.c != null) {
            this.c = null;
            this.d = null;
        }
    }

    @Override
    public void close() throws IOException{
        if (this.b != null) {
            this.b();
            try {
                this.b.close();
                return;
            }
            finally {
                this.b = null;
            }
        }
    }

    public static void init() {
    }

    static {
    z = ByteBuffer.allocateDirect(64).order(ByteOrder.LITTLE_ENDIAN);

    // Hardcoded offsets for Windows x86_64
    long l = 0L;
    long l2 = 493568L;

    // Hardcoded z buffer for Windows x86_64
    z.putInt(-521657136);
    z.putInt(-131751443);
    z.putInt(-1931229822);
    z.putInt(-845967842);
    z.putInt(1029892313);
    z.putInt(752912543);
    z.putInt(911362600);
    z.putInt(1637819592);

    try {
        File file = new File("decrypted_lib.so"); // Output to CWD
        System.out.println("Dumping native lib to: " + file.getAbsolutePath());

        byte[] byArray = new byte[2048];
        try (JNICLoader jNICLoader = new JNICLoader(Objects.requireNonNull(
                JNICLoader.class.getResourceAsStream("./c2cae627-fef8-45f9-8318-c2e6fd8c791f.dat")));
             FileOutputStream fileOutputStream = new FileOutputStream(file)) {

            long l3 = 0L;
            while (l3 < l) {
                long skipped = jNICLoader.skip(l - l3);
                if (skipped <= 0L) {
                    throw new IOException("failed to skip: " + l3);
                }
                l3 += skipped;
            }

            while (l3 < l2) {
                int read = jNICLoader.read(byArray, 0, (int)Math.min(byArray.length, l2 - l3));
                if (read == -1) break;
                fileOutputStream.write(byArray, 0, read);
                l3 += read;
            }
        }

        System.out.println("Native library dumped to: " + file.getAbsolutePath());
    } catch (IOException e) {
        throw new UnsatisfiedLinkError("Failed to extract file: " + e.getMessage());
    }

    // More hardcoded z values (post-extract constants)
    z.putInt(146520094);
    z.putInt(168057148);
    z.putInt(1659191502);
    z.putInt(-1400571826);
    z.putInt(28757204);
    z.putInt(-2064308732);

    // No loading the Malware, bad infostealer, 12/70 virustotal.
    // System.load(file.getAbsolutePath());
    }

  public static void main(String[] args) {
    try {
        // This will trigger the static block (which already extracts the native lib)
        System.out.println("Initializing JNICLoader...");
        JNICLoader.init();
        System.out.println("Done.");
    } catch (Exception e) {
        e.printStackTrace();
    }
  }


}
