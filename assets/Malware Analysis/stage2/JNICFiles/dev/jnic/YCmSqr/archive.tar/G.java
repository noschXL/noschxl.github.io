/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.io.IOException;

import dev.jnic.YCmSqr.I;
import dev.jnic.YCmSqr.S;
import dev.jnic.YCmSqr.V;
import dev.jnic.YCmSqr.a;
import dev.jnic.YCmSqr.e;
import dev.jnic.YCmSqr.j;
import dev.jnic.YCmSqr.k;
import dev.jnic.YCmSqr.n;

public final class G
extends I {
    private n c;
    final e O;
    private final a P;
    private final V Q = new V(this,(byte) 0);
    private final V R = new V(this, (byte)0);

    public G(n n2, e e2, int n3, int n4, int n5) throws IOException{
        super(n5);
        this.c = n2;
        this.O = e2;
        this.P = new a(this, n3, n4);
        this.c();
    }

    @Override
    public final void c() {
        super.c();
        this.P.c();
        this.Q.c();
        this.R.c();
    }

    public final void d() throws IOException{
        n n2 = this.c;
        if (n2.s > 0) {
            n n3 = n2;
            n3.a(n3.t, n2.s);
        }
        while (true) {
            int n4;
            block20: {
                G g;
                int n5;
                block22: {
                    int n6;
                    block21: {
                        int n7;
                        block19: {
                            int n8;
                            int n9;
                            n2 = this.c;
                            if (!(n2.p < n2.r)) break;
                            n7 = this.c.p & this.v;
                            if (this.O.a(this.y[this.x.S], n7) == 0) {
                                a a2 = this.P;
                                int n10 = a2.T.c.p;
                                int n11 = a2.T.c.b(0);
                                Object object = a2;
                                int n12 = n11 >> 8 - ((j)object).L;
                                n9 = (n10 & ((j)object).M) << ((j)object).L;
                                n11 = n12 + n9;
                                object = a2.U[n11];
                                n11 = 1;
                                if (((S)object).V.T.x.S < 7) {
                                    while ((n11 = n11 << 1 | ((S)object).V.T.O.a(((S)object).N, n11)) < 256) {
                                    }
                                } else {
                                    n10 = ((S)object).V.T.c.b(((S)object).V.T.w[0]);
                                    n12 = 256;
                                    do {
                                        n9 = (n10 <<= 1) & n12;
                                        n8 = ((S)object).V.T.O.a(((S)object).N, n12 + n9 + n11);
                                        n11 = n11 << 1 | n8;
                                        n12 &= 0 - n8 ^ ~n9;
                                    } while (n11 < 256);
                                }
                                byte by = (byte)n11;
                                n n13 = ((S)object).V.T.c;
                                n13.m[n13.p++] = by;
                                if (n13.q < n13.p) {
                                    n13.q = n13.p;
                                }
                                k k2 = ((S)object).V.T.x;
                                if (k2.S <= 3) {
                                    k2.S = 0;
                                    continue;
                                }
                                if (k2.S <= 9) {
                                    k2.S -= 3;
                                    continue;
                                }
                                k2.S -= 6;
                                continue;
                            }
                            if (this.O.a(this.z, this.x.S) != 0) break block19;
                            n5 = n7;
                            G g2 = this;
                            g2.x.S = g2.x.S < 7 ? 7 : 10;
                            g2.w[3] = g2.w[2];
                            g2.w[2] = g2.w[1];
                            g2.w[1] = g2.w[0];
                            int n14 = g2.Q.c(n5);
                            int n15 = n14;
                            if ((n5 = g2.O.a(g2.E[n15 < 6 ? n15 - 2 : 3])) < 4) {
                                g2.w[0] = n5;
                            } else {
                                int n16 = (n5 >> 1) - 1;
                                g2.w[0] = (2 | n5 & 1) << n16;
                                if (n5 < 14) {
                                    g2.w[0] = g2.w[0] | g2.O.b(g2.F[n5 - 4]);
                                } else {
                                    int n17 = g2.w[0];
                                    n9 = n16 - 4;
                                    e e2 = g2.O;
                                    n8 = 0;
                                    do {
                                        e2.e();
                                        e2.W >>>= 1;
                                        n5 = e2.X - e2.W >>> 31;
                                        e2.X -= e2.W & n5 - 1;
                                        n8 = n8 << 1 | 1 - n5;
                                    } while (--n9 != 0);
                                    g2.w[0] = n17 | n8 << 4;
                                    g2.w[0] = g2.w[0] | g2.O.b(g2.G);
                                }
                            }
                            n4 = n14;
                            break block20;
                        }
                        n5 = n7;
                        g = this;
                        if (g.O.a(g.A, g.x.S) != 0) break block21;
                        if (g.O.a(g.D[g.x.S], n5) != 0) break block22;
                        g.x.S = g.x.S < 7 ? 9 : 11;
                        n4 = 1;
                        break block20;
                    }
                    if (g.O.a(g.B, g.x.S) == 0) {
                        n6 = g.w[1];
                    } else {
                        if (g.O.a(g.C, g.x.S) == 0) {
                            n6 = g.w[2];
                        } else {
                            n6 = g.w[3];
                            g.w[3] = g.w[2];
                        }
                        g.w[2] = g.w[1];
                    }
                    g.w[1] = g.w[0];
                    g.w[0] = n6;
                }
                g.x.S = g.x.S < 7 ? 8 : 11;
                n4 = g.R.c(n5);
            }
            int n18 = n4;
            this.c.a(this.w[0], n18);
        }
        this.O.e();
    }
}
