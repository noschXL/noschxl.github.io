/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.io.IOException;

public abstract class e {
    public int W = 0;
    public int X = 0;

    public abstract void e() throws IOException;

    public final int a(short[] sArray, int n) throws IOException{
        int n2;
        this.e();
        short s = sArray[n];
        int n3 = (this.W >>> 11) * s;
        if ((this.X ^ Integer.MIN_VALUE) < (n3 ^ Integer.MIN_VALUE)) {
            this.W = n3;
            sArray[n] = (short)(s + (2048 - s >>> 5));
            n2 = 0;
        } else {
            this.W -= n3;
            this.X -= n3;
            short s2 = s;
            sArray[n] = (short)(s2 - (s2 >>> 5));
            n2 = 1;
        }
        return n2;
    }

    public final int a(short[] sArray) throws IOException{
        int n = 1;
        while ((n = n << 1 | this.a(sArray, n)) < sArray.length) {
        }
        return n - sArray.length;
    }

    public final int b(short[] sArray) throws IOException{
        int n = 1;
        int n2 = 0;
        int n3 = 0;
        do {
            int n4 = this.a(sArray, n);
            n = n << 1 | n4;
            n3 |= n4 << n2++;
        } while (n < sArray.length);
        return n3;
    }
}
