/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import dev.jnic.YCmSqr.k;
import java.util.Arrays;

abstract class I {
    final int v;
    final int[] w = new int[4];
    final k x = new k();
    final short[][] y = new short[12][16];
    final short[] z = new short[12];
    final short[] A = new short[12];
    final short[] B = new short[12];
    final short[] C = new short[12];
    final short[][] D = new short[12][16];
    final short[][] E = new short[4][64];
    final short[][] F = new short[][]{new short[2], new short[2], new short[4], new short[4], new short[8], new short[8], new short[16], new short[16], new short[32], new short[32]};
    final short[] G = new short[16];

    I(int n) {
        this.v = (1 << n) - 1;
    }

    void c() {
        int n;
        this.w[0] = 0;
        this.w[1] = 0;
        this.w[2] = 0;
        this.w[3] = 0;
        this.x.S = 0;
        for (n = 0; n < this.y.length; ++n) {
            Arrays.fill(this.y[n], (short)1024);
        }
        Arrays.fill(this.z, (short)1024);
        Arrays.fill(this.A, (short)1024);
        Arrays.fill(this.B, (short)1024);
        Arrays.fill(this.C, (short)1024);
        for (n = 0; n < this.D.length; ++n) {
            Arrays.fill(this.D[n], (short)1024);
        }
        for (n = 0; n < this.E.length; ++n) {
            Arrays.fill(this.E[n], (short)1024);
        }
        for (n = 0; n < this.F.length; ++n) {
            Arrays.fill(this.F[n], (short)1024);
        }
        Arrays.fill(this.G, (short)1024);
    }
}
