/*
 * Decompiled with CFR 0.152.
 */
package dev.jnic.YCmSqr;

import java.io.IOException;

public final class n {
    public final byte[] m;
    public final int n;
    public int o = 0;
    public int p = 0;
    public int q = 0;
    public int r = 0;
    public int s = 0;
    public int t = 0;

    public n(int n2, byte[] byArray) {
        this.n = n2;
        this.m = new byte[this.n];
        if (byArray != null) {
            this.q = this.p = Math.min(byArray.length, n2);
            this.o = this.p;
            System.arraycopy(byArray, byArray.length - this.p, this.m, 0, this.p);
        }
    }

    public final int b(int n2) {
        int n3 = this.p - n2 - 1;
        if (n2 >= this.p) {
            n3 += this.n;
        }
        return this.m[n3] & 0xFF;
    }

    public final void a(int n2, int n3) throws IOException{
        int n4;
        if (n2 < 0 || n2 >= this.q) {
            throw new IOException();
        }
        int n5 = Math.min(this.r - this.p, n3);
        this.s = n3 - n5;
        this.t = n2;
        n3 = this.p - n2 - 1;
        if (n3 < 0) {
            assert (this.q == this.n);
            n4 = Math.min(this.n - (n3 += this.n), n5);
            assert (n4 <= n2 + 1);
            System.arraycopy(this.m, n3, this.m, this.p, n4);
            this.p += n4;
            n3 = 0;
            if ((n5 -= n4) == 0) {
                return;
            }
        }
        assert (n3 < this.p);
        assert (n5 > 0);
        do {
            n4 = Math.min(n5, this.p - n3);
            System.arraycopy(this.m, n3, this.m, this.p, n4);
            this.p += n4;
        } while ((n5 -= n4) > 0);
        if (this.q < this.p) {
            this.q = this.p;
        }
    }
}
